#include <stdio.h>
#include <stdlib.h>
#include <math.h>


// Function to count number of appearance of a in b
int countAppear(int a, int b) {
	int t = 0;
	int pow=1;
   	while(a>0){
   		t=a%10 + t*10;
		a /=10;
		pow=pow*10;
	    }
	int u = 0;
	int ob=b;
   	while(b>0){
   		u=b%10 + u*10;
		b /=10;
	    }
	int tam;
	int count=0;
	while (u>0){
		tam=u % pow;
		if (tam==t){
			count++;
		}
		u/=10;
	}	
	return count;
}



//========DO NOT ADD NEW OR CHANGE THE STATEMENTS IN THE MAIN FUNCTION========
int main()
{ 
	system("cls");
	printf("\nTEST Q4 (2 marks):\n");
	int a, b;
	printf("Enter a = "); scanf("%d", &a);
	printf("Enter b = "); scanf("%d", &b);

  	printf("\nOUTPUT:\n"); 		
  	int count = countAppear(a, b);
  	printf("%d", count);
  	
  	
  	printf("\n");
  	system ("pause");
  	return 0; 
}
//========//==================================================================
