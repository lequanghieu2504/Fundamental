#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int countKWord(char* s, int k) {
    int t=0;
    int i;
    int pos;
    int count = 0;
    for(i=0; i<strlen(s); i++){
    	if (isspace(s[i])){
    		t++;
		}
		if (t==k){
			pos=i+1;
			break;
		}
	}
	while (isalpha(s[pos])){
		count++;
		pos++;
	}
	return count;
}



//========DO NOT ADD NEW OR CHANGE THE STATEMENTS IN THE MAIN FUNCTION========
int main()
{ 
	system("cls");
	printf("\nTEST Q4 (2 marks):\n");
	int k;
	char s[1000];
	printf("Enter s = "); 
	gets(s);
	printf("Enter k = "); scanf("%d", &k);

  	printf("\nOUTPUT:\n"); 		
  	int count = countKWord(s, k);
  	printf("%d", count);
  	
  	
  	printf("\n");
  	system ("pause");
  	return 0; 
}
//========//==================================================================
