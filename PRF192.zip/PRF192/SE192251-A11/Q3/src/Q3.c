#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

bool isprime(int n) {
	int i;
    if (n < 2) return false;
    if (n == 2) return true;
    if (n % 2 == 0) return false;
    for ( i = 3; i * i <= n; i += 2) {
        if (n % i == 0) return false;
    }
    return true;
}

int isEmirpNo(int n) {
    int t = 0;
    int original = n;
    while (n > 0) {
        t = n%10+t*10;
        n /= 10;
    }
    if (isprime(t) && isprime(original) && t != original) {
        return 1;
    } else {
        return 0;
    }
}

//========DO NOT ADD NEW OR CHANGE THE STATEMENTS IN THE MAIN FUNCTION========
int main() {
    system("cls");
    printf("\nTEST Q3 (3 marks):\n");
    int n;
    printf("Enter n = "); scanf("%d", &n);

    printf("\nOUTPUT:\n");
    int check = isEmirpNo(n);
    if (check == 1) printf("True");
    else printf("False");
    printf("\n");
    system("pause");
    return 0;
}
//========//==================================================================

