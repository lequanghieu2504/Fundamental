#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

bool ktmang (int s[], int t, int n){
	int i;
	for (i=0; i<n; i++){
		if (t==s[i]){
			return false;
		}
	}
	return true;
}

int countUniqueDivisor(int* a, int n){
	int count=0;
	int i,j;
	int s[100];
	int b=0;
	for (i=0; i<n; i++){
		for (j=1; j<=a[i]; j++){
			if (a[i]%j==0){
			if (ktmang(s, j, b)){
					s[b] = j;
					b++;
					count++;
				}
			}
		}
	}
	return count;
}


//========DO NOT ADD NEW OR CHANGE THE STATEMENTS IN THE MAIN FUNCTION========
int main()
{ 
	system("cls");
	printf("\nTEST Q3 (2 marks):\n");
	int n;
	printf("Enter n = "); scanf("%d",&n);
	int a[100], i;
	printf("Arr: ");
	for (i = 0; i < n; i++)
		scanf("%d", &a[i]);
		
		

  	printf("\nOUTPUT:\n");  		
  	printf("%d", countUniqueDivisor(a, n));
  	printf("\n");
  	system ("pause");
  	return 0; 
}
//========//==================================================================
