#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define MAX 100
#include <stdbool.h>
void inputArray(int a[], int n);
void printArray(int a[], int n);
int sumPrimeArray(int a[], int n);


//=== Do not add new or change statements in the main function.===
int main() {

	system("cls");
  	printf("\nTEST Q3 (3 marks):\n");
	int n, a[MAX],sum=0;	
	char c;
	do {
		printf("How many elements do you want to enter into the integer array? [1..100] ");
		fflush(stdin);
		scanf("%d%c", &n, &c);
	} while(n<1 || n>MAX || c != '\n');	
	inputArray(a,n);
			
	//=== The output will be used to mark your program.===============
	printf("\nOUTPUT:\n");
  	sum=sumPrimeArray(a,n); 
  	printf("%d",sum);
  	printf("\n");
  	system ("pause");	
	return 0;
}
//=== Do not add new or change statements in this function.===
void inputArray(int a[], int n) {	
    int i;
	for(i=0; i<n; i++) {
		printf("a[%d] = ", i);
		scanf("%d", &a[i]);
	}
}
//This function checks n whether is prime or not
//if true then return 1, otherwise return 0
bool isPrimeNumber(int n){
	if (n<2) return false;
	if (n==2) return true;
	if (n%2==0) return false;
	int i;
	for (i=3; i*i<=n; i+=2){
		if (n%i==0) return false;
	}
	return true;
}
//----------------------------------------------
int sumPrimeArray(int a[], int n) {
	int i;
	int sum=0;
	for (i=0; i<n; i++){
		if (isPrimeNumber(a[i])){
			sum+=a[i];
		}
	}
	return sum;
}

