#include<stdio.h>

int main() {
	float chuvi, bankinh ;
	printf ("nhap chu vi: ");
	scanf("%f", &chuvi);
	printf("bankinh = %f", chuvi/3.14/2);
	return 0;
}

