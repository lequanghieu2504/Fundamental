#include <stdio.h>
#include <stdlib.h>
#include <math.h>


// Function to calculate the equation S
float calculateS(int n) {
    float s = 0;
	int i;
	for (i=1; i<=n; i++){
		int a=i+2;
		s=s*1.0+i*1.0/a;
	}
	return s;
}

//========DO NOT ADD NEW OR CHANGE THE STATEMENTS IN THE MAIN FUNCTION========
int main()
{ 
	system("cls");
	printf("\nTEST Q1 (2 marks):\n");
	int n;
	printf("Enter n = "); scanf("%d",&n);


  	printf("\nOUTPUT:\n");
  	float s = calculateS(n);
  	printf("%.2f", s);
  	printf("\n");
  	system ("pause");
  	return 0; 
}
//========//==================================================================
