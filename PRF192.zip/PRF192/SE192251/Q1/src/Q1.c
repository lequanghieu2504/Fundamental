#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

bool isPrime(int n){
	if (n<2) return false;
	if (n==2) return true;
	if (n%2==0)  return false;
	int i;
	for (i=3; i*i<=n; i+=2){
		if (n%i==0) return false;
	}
	return true;
}


void changePrime(int* a, int n) {
    int i;
    int sum=0;
    for (i=0; i<n; i++){
    	sum+=a[i];
	}
	for (i=0; i<n; i++){
		if (isPrime(a[i])){
			a[i]=sum;
		}
	}
}



//========DO NOT ADD NEW OR CHANGE THE STATEMENTS IN THE MAIN FUNCTION========
int main()
{ 
	system("cls");
	printf("\nTEST Q1 (3 marks):\n");
	int n;
	printf("Enter n = "); scanf("%d",&n);
	int a[100], i;
	printf("Arr: ");
	for (i = 0; i < n; i++)
		scanf("%d", &a[i]);


  	printf("\nOUTPUT:\n");
  	changePrime(a, n);
  	for (i = 0; i < n; i++)
		printf("%d ", a[i]);
  	
  	printf("\n");
  	system ("pause");
  	return 0; 
}
//========//==================================================================
