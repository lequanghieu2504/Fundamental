#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

bool isSquared(int n){
	int a=sqrt(n);
	return n==a*a;
}

float calcAverageSquareNumber(int* a, int n) {
    float avr;
    int i;
    int count=0;
    int sum=0;
    for (i=0; i<n; i++){
    	if (isSquared(a[i])){
    		sum += a[i];
    		count ++;
		}
	}
	avr=sum*1.0/count;
	return avr;
}



//========DO NOT ADD NEW OR CHANGE THE STATEMENTS IN THE MAIN FUNCTION========
int main()
{ 
	system("cls");
	printf("\nTEST Q2 (3 marks):\n");
	int n;
	printf("Enter n = "); scanf("%d",&n);
	int a[100], i;
	printf("Arr: ");
	for (i = 0; i < n; i++)
		scanf("%d", &a[i]);


  	printf("\nOUTPUT:\n");
  	float avg = calcAverageSquareNumber(a, n);
  	printf("%.2f", avg);
  	printf("\n");
  	system ("pause");
  	return 0; 
}
//========//==================================================================
