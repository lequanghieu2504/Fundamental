#include <stdio.h>
#include <stdlib.h>
#include <math.h>


// Function to calculate the average of all perfect square number
float calcAverageSquareNumber(int n) {
    float avg = 0;
    int i,j=0;
    int sum =0;
    for (i=1; i<=n;i++){
    int a=sqrt(i);
	if (a*a==i){
		sum+=i;
		j++;
		avg=sum*1.0/j;
	}
	}
	return avg;
}



//========DO NOT ADD NEW OR CHANGE THE STATEMENTS IN THE MAIN FUNCTION========
int main()
{ 
	system("cls");
	printf("\nTEST Q2 (3 marks):\n");
	int n;
	printf("Enter n = "); scanf("%d",&n);


  	printf("\nOUTPUT:\n");
  	float avg = calcAverageSquareNumber(n);
  	printf("%.2f", avg);
  	printf("\n");
  	system ("pause");
  	return 0; 
}
//========//==================================================================
